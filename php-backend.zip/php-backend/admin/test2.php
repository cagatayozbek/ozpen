<?php
echo "PHP ÇALIŞIYOR! ✅";
phpinfo();
?>
